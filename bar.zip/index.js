'use strict';
const AWS = require('aws-sdk');
exports.handler = async (event, context, callback) => {
    console.log('hello world');
};
