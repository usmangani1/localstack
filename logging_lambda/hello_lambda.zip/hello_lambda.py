import os
from datetime import timedelta, datetime

import boto3

LOCALSTACK_HOSTNAME = os.environ.get("LOCALSTACK_HOSTNAME")
if LOCALSTACK_HOSTNAME:
    DYNAMODB_ENDPOINT_URL = f"http://{LOCALSTACK_HOSTNAME}:4566"
else:
    DYNAMODB_ENDPOINT_URL = os.environ.get("DYNAMODB_ENDPOINT_URL")

table = boto3.resource('dynamodb',
                       endpoint_url=DYNAMODB_ENDPOINT_URL).Table('Logging')


def log_message(message: str) -> None:
    t0 = datetime(1, 1, 1)
    now = datetime.utcnow()
    seconds = (now - t0).total_seconds()
    table.put_item(
        Item={
            'Timestamp': int(seconds),
            'Message': message
        }
    )


def lambda_handler(event, context):
    log_message("Lambda Triggered")
